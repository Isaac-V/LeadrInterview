﻿using LeadrInterview.FakeDatabase.Model;
using LeadrInterview.FakeDatabaseNamespace;
using Microsoft.AspNetCore.Mvc;

namespace RestApi.Controllers
{
    [ApiController]
    [Route("api/v1/people")]
    public class PeopleController : ControllerBase
    {
        private readonly FakeDatabase _db;

        public PeopleController(FakeDatabase db)
        {
            _db = db;
        }

        [HttpPost]
        public IActionResult AddPerson([FromBody] Person personData)
        {
            if (_db.Add(personData))
                return Ok();
            else
                return Conflict();
        }


        [HttpGet]
        public IActionResult GetPerson(string email)
        {
            var person = _db.Get(email);

            if (person != null)
                return new OkObjectResult(person);
            else
                return NotFound();
        }
    }
}
