﻿using LeadrInterview.FakeDatabase.Model;
using System.Collections.Generic;

namespace LeadrInterview.FakeDatabaseNamespace
{
    public interface IFakeDatabase
    {
        bool Add(Person person);
        Person Get(string email);
    }

    public class FakeDatabase
    {
        public Dictionary<string, Person> _db { get; }

        public FakeDatabase()
        {
            _db = new Dictionary<string, Person>();
        }
        
        public bool Add(Person person)
        {
            if (person?.Email != null && !_db.ContainsKey(person.Email))
            {
                _db[person.Email] = person;
                return true;
            }

            return false;
        }

        public Person Get(string email)
        {
            if (_db.ContainsKey(email))
                return _db[email];
            else
                return null;
        }
    }
}
