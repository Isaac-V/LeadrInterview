﻿using System.Collections.Generic;

namespace LeadrInterview.FakeDatabase.Model
{
    public class Person
    {
        public string FullName { get; set; }
        public string Email { get; set; }
        public HashSet<string> DirectReportEmails { get; set; }
    }
}
